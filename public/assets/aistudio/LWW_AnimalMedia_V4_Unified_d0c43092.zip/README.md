# Little Wonder World 2.0 — Complete Unified Media Library (v4.0)

This single archive contains all generated images, educational lesson videos, real-animal movement videos, English narration audio, verified authentic animal sound recordings, multilingual subtitles (EN/TE/HI), and metadata organized under their respective folders:

## Folder Structure
- `animals/` — 64 realistic animal cards (`1024 × 1024` WebP) organized by category:
  - `animals/domestic/` (11 WebP images)
  - `animals/wild/` (17 WebP images)
  - `animals/birds/` (13 WebP images)
  - `animals/aquatic/` (9 WebP images)
  - `animals/insects/` (8 WebP images)
  - `animals/reptiles/` (6 WebP images)
- `objects/` — 71 educational object illustrations (`1024 × 1024` WebP & vector SVG) organized by category:
  - `objects/fruits/` (12 WebP images)
  - `objects/vegetables/` (11 WebP images)
  - `objects/vehicles/` (13 WebP images)
  - `objects/shapes/` (10 SVG vector shapes)
  - `objects/everyday/` (14 WebP images)
  - `objects/nature/` (11 WebP images)
- `thumbnails/` — 16 lesson video cover thumbnails (WebP)
- `videos/` — 22 MP4 videos (`1280 × 720`, H.264) + 48 multilingual subtitle files (`.srt`, `.te.srt`, `.hi.srt`):
  - `videos/animals/` (6 real-animal CC0 1.0 movement MP4 videos: Elephant, Dog, Cat, Cow, Horse, Goat)
  - `videos/animal_lessons/` (5 lesson MP4s + 15 subtitle files)
  - `videos/object_lessons/` (4 lesson MP4s + 12 subtitle files)
  - `videos/good_habits/` (3 lesson MP4s + 9 subtitle files)
  - `videos/numbers/` (1 lesson MP4 + 3 subtitle files)
  - `videos/science/` (3 lesson MP4s + 9 subtitle files)
- `audio/` — 22 MP3 audio files (`44.1 kHz`, normalized):
  - `audio/animal_sounds/` (6 verified authentic wildlife MP3s: Elephant, Lion, Dog, Cow, Horse, Whale)
  - `audio/narration/` (16 English lesson narration MP3s)
- `metadata/` — Complete JSON catalogs (`animals.json`, `lessons.json`, `objects.json`, `translations_en.json`, `translations_hi.json`, `translations_te.json`)
- `prompts/` — `image_prompts.md`, `veo_prompts.md`
- `reports/` — `RESOLUTION_REPORT.json`, `QA_REPORT_V4.md`, `asset_inventory.csv`, `missing_assets.csv`, `optimization_report.csv`
- `scripts/` — `export_remaining_veo_and_audio.py`
