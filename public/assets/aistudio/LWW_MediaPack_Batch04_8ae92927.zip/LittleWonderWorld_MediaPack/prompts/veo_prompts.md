# Little Wonder World 2.0 — Batch04 Google Veo 2 Video Prompts

### Peacock (`bird_peacock`)
* **Target Path**: `videos/animals/peacock_movement.mp4`
* **Reference Frame**: `animals/birds/peacock.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Peacock (Pavo cristatus) from the reference image (animals/birds/peacock.webp) moving gently and naturally in Forests, Gardens, and Farmlands in India. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Parrot (`bird_parrot`)
* **Target Path**: `videos/animals/parrot_movement.mp4`
* **Reference Frame**: `animals/birds/parrot.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Parrot (Psittacula krameri) from the reference image (animals/birds/parrot.webp) moving gently and naturally in Tropical Trees, Orchards, and Gardens. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Crow (`bird_crow`)
* **Target Path**: `videos/animals/crow_movement.mp4`
* **Reference Frame**: `animals/birds/crow.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Crow (Corvus splendens) from the reference image (animals/birds/crow.webp) moving gently and naturally in Trees, Parks, and Human Neighborhoods. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Sparrow (`bird_sparrow`)
* **Target Path**: `videos/animals/sparrow_movement.mp4`
* **Reference Frame**: `animals/birds/sparrow.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Sparrow (Passer domesticus) from the reference image (animals/birds/sparrow.webp) moving gently and naturally in Gardens, Courtyards, and Eaves of Houses. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Pigeon (`bird_pigeon`)
* **Target Path**: `videos/animals/pigeon_movement.mp4`
* **Reference Frame**: `animals/birds/pigeon.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Pigeon (Columba livia) from the reference image (animals/birds/pigeon.webp) moving gently and naturally in Town Squares, Cliffs, and Park Rooftops. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Eagle (`bird_eagle`)
* **Target Path**: `videos/animals/eagle_movement.mp4`
* **Reference Frame**: `animals/birds/eagle.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Eagle (Aquila chrysaetos) from the reference image (animals/birds/eagle.webp) moving gently and naturally in High Mountains, Cliffs, and Open Skies. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Owl (`bird_owl`)
* **Target Path**: `videos/animals/owl_movement.mp4`
* **Reference Frame**: `animals/birds/owl.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Owl (Bubo bubo) from the reference image (animals/birds/owl.webp) moving gently and naturally in Forest Hollows and Old Trees at Night. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Duck (`bird_duck`)
* **Target Path**: `videos/animals/duck_movement.mp4`
* **Reference Frame**: `animals/birds/duck.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Duck (Anas platyrhynchos) from the reference image (animals/birds/duck.webp) moving gently and naturally in Ponds, Lakes, and Gentle Rivers. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Hen (`bird_hen`)
* **Target Path**: `videos/animals/hen_movement.mp4`
* **Reference Frame**: `animals/birds/hen.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Hen (Gallus gallus domesticus) from the reference image (animals/birds/hen.webp) moving gently and naturally in Farms, Coops, and Country Barnyards. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Rooster (`bird_rooster`)
* **Target Path**: `videos/animals/rooster_movement.mp4`
* **Reference Frame**: `animals/birds/rooster.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Rooster (Gallus gallus domesticus) from the reference image (animals/birds/rooster.webp) moving gently and naturally in Farms and Village Barnyards. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Penguin (`bird_penguin`)
* **Target Path**: `videos/animals/penguin_movement.mp4`
* **Reference Frame**: `animals/birds/penguin.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Penguin (Aptenodytes forsteri) from the reference image (animals/birds/penguin.webp) moving gently and naturally in Snowy Antarctic Ice and Cold Southern Oceans. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Flamingo (`bird_flamingo`)
* **Target Path**: `videos/animals/flamingo_movement.mp4`
* **Reference Frame**: `animals/birds/flamingo.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Flamingo (Phoenicopterus roseus) from the reference image (animals/birds/flamingo.webp) moving gently and naturally in Shallow Lagoons and Warm Salt Lakes. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Ostrich (`bird_ostrich`)
* **Target Path**: `videos/animals/ostrich_movement.mp4`
* **Reference Frame**: `animals/birds/ostrich.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Ostrich (Struthio camelus) from the reference image (animals/birds/ostrich.webp) moving gently and naturally in African Savannas and Sandy Plains. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`
