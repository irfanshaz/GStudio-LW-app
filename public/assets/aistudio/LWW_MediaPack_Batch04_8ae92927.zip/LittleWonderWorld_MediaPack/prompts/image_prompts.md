# Little Wonder World 2.0 — Batch04 Image Generation Prompts

### Peacock (`bird_peacock`)
* **Target Path**: `animals/birds/peacock.webp`
* **Prompt**: `A realistic, scientifically accurate adult Peacock (Pavo cristatus) in its natural habitat (Forests, Gardens, and Farmlands in India). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Parrot (`bird_parrot`)
* **Target Path**: `animals/birds/parrot.webp`
* **Prompt**: `A realistic, scientifically accurate adult Parrot (Psittacula krameri) in its natural habitat (Tropical Trees, Orchards, and Gardens). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Crow (`bird_crow`)
* **Target Path**: `animals/birds/crow.webp`
* **Prompt**: `A realistic, scientifically accurate adult Crow (Corvus splendens) in its natural habitat (Trees, Parks, and Human Neighborhoods). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Sparrow (`bird_sparrow`)
* **Target Path**: `animals/birds/sparrow.webp`
* **Prompt**: `A realistic, scientifically accurate adult Sparrow (Passer domesticus) in its natural habitat (Gardens, Courtyards, and Eaves of Houses). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Pigeon (`bird_pigeon`)
* **Target Path**: `animals/birds/pigeon.webp`
* **Prompt**: `A realistic, scientifically accurate adult Pigeon (Columba livia) in its natural habitat (Town Squares, Cliffs, and Park Rooftops). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Eagle (`bird_eagle`)
* **Target Path**: `animals/birds/eagle.webp`
* **Prompt**: `A realistic, scientifically accurate adult Eagle (Aquila chrysaetos) in its natural habitat (High Mountains, Cliffs, and Open Skies). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Owl (`bird_owl`)
* **Target Path**: `animals/birds/owl.webp`
* **Prompt**: `A realistic, scientifically accurate adult Owl (Bubo bubo) in its natural habitat (Forest Hollows and Old Trees at Night). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Duck (`bird_duck`)
* **Target Path**: `animals/birds/duck.webp`
* **Prompt**: `A realistic, scientifically accurate adult Duck (Anas platyrhynchos) in its natural habitat (Ponds, Lakes, and Gentle Rivers). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Hen (`bird_hen`)
* **Target Path**: `animals/birds/hen.webp`
* **Prompt**: `A realistic, scientifically accurate adult Hen (Gallus gallus domesticus) in its natural habitat (Farms, Coops, and Country Barnyards). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Rooster (`bird_rooster`)
* **Target Path**: `animals/birds/rooster.webp`
* **Prompt**: `A realistic, scientifically accurate adult Rooster (Gallus gallus domesticus) in its natural habitat (Farms and Village Barnyards). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Penguin (`bird_penguin`)
* **Target Path**: `animals/birds/penguin.webp`
* **Prompt**: `A realistic, scientifically accurate adult Penguin (Aptenodytes forsteri) in its natural habitat (Snowy Antarctic Ice and Cold Southern Oceans). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Flamingo (`bird_flamingo`)
* **Target Path**: `animals/birds/flamingo.webp`
* **Prompt**: `A realistic, scientifically accurate adult Flamingo (Phoenicopterus roseus) in its natural habitat (Shallow Lagoons and Warm Salt Lakes). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Ostrich (`bird_ostrich`)
* **Target Path**: `animals/birds/ostrich.webp`
* **Prompt**: `A realistic, scientifically accurate adult Ostrich (Struthio camelus) in its natural habitat (African Savannas and Sandy Plains). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Train (`vehicle_train`)
* **Target Path**: `objects/vehicles/train.webp`
* **Prompt**: `A single clean, accurate, child-friendly Train (Blue / Silver), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Aeroplane (`vehicle_aeroplane`)
* **Target Path**: `objects/vehicles/aeroplane.webp`
* **Prompt**: `A single clean, accurate, child-friendly Aeroplane (White / Blue), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Helicopter (`vehicle_helicopter`)
* **Target Path**: `objects/vehicles/helicopter.webp`
* **Prompt**: `A single clean, accurate, child-friendly Helicopter (Red / White), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Bicycle (`vehicle_bicycle`)
* **Target Path**: `objects/vehicles/bicycle.webp`
* **Prompt**: `A single clean, accurate, child-friendly Bicycle (Bright Green), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Motorcycle (`vehicle_motorcycle`)
* **Target Path**: `objects/vehicles/motorcycle.webp`
* **Prompt**: `A single clean, accurate, child-friendly Motorcycle (Blue), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Tractor (`vehicle_tractor`)
* **Target Path**: `objects/vehicles/tractor.webp`
* **Prompt**: `A single clean, accurate, child-friendly Tractor (Green / Yellow), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Truck (`vehicle_truck`)
* **Target Path**: `objects/vehicles/truck.webp`
* **Prompt**: `A single clean, accurate, child-friendly Truck (Orange / Red), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Boat (`vehicle_boat`)
* **Target Path**: `objects/vehicles/boat.webp`
* **Prompt**: `A single clean, accurate, child-friendly Boat (White / Wood), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Ship (`vehicle_ship`)
* **Target Path**: `objects/vehicles/ship.webp`
* **Prompt**: `A single clean, accurate, child-friendly Ship (White / Navy Blue), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Ambulance (`vehicle_ambulance`)
* **Target Path**: `objects/vehicles/ambulance.webp`
* **Prompt**: `A single clean, accurate, child-friendly Ambulance (White with Red Cross), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Fire Engine (`vehicle_fire_engine`)
* **Target Path**: `objects/vehicles/fire_engine.webp`
* **Prompt**: `A single clean, accurate, child-friendly Fire Engine (Bright Red), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`
