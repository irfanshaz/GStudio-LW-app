# Little Wonder World 2.0 — Batch02 (Domestic Animals, Fruits & Geometric Shapes Pack)

* **Media Pack Version**: `2.0.0-batch.02`
* **Target App**: Little Wonder World 2.0 (100% Offline Android WebView Educational App for ages 3–8)
* **Supported Languages**: English (`en`), Telugu (`te`), Hindi (`hi`)
* **Animals Metadata & Assets**: 9 animals
* **Objects & Shapes Metadata & Assets**: 19 objects/shapes
* **Offline 720p H.264/AAC Video Lessons**: 3 completed lessons with EN/TE/HI `.srt` subtitles and `.mp3` narration tracks.
