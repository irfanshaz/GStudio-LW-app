# Little Wonder World 2.0 — Batch02 Google Veo 2 Video Prompts

### Cow (`domestic_cow`)
* **Target Path**: `videos/animals/cow_movement.mp4`
* **Reference Frame**: `animals/domestic/cow.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Cow (Bos taurus) from the reference image (animals/domestic/cow.webp) moving gently and naturally in Farms, Pastures, and Rural Villages. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Buffalo (`domestic_buffalo`)
* **Target Path**: `videos/animals/buffalo_movement.mp4`
* **Reference Frame**: `animals/domestic/buffalo.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Buffalo (Bubalus bubalis) from the reference image (animals/domestic/buffalo.webp) moving gently and naturally in Farms, Riverbanks, and Muddy Pastures. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Goat (`domestic_goat`)
* **Target Path**: `videos/animals/goat_movement.mp4`
* **Reference Frame**: `animals/domestic/goat.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Goat (Capra hircus) from the reference image (animals/domestic/goat.webp) moving gently and naturally in Farms, Hillsides, and Meadows. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Sheep (`domestic_sheep`)
* **Target Path**: `videos/animals/sheep_movement.mp4`
* **Reference Frame**: `animals/domestic/sheep.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Sheep (Ovis aries) from the reference image (animals/domestic/sheep.webp) moving gently and naturally in Green Hills, Pastures, and Farm Meadows. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Horse (`domestic_horse`)
* **Target Path**: `videos/animals/horse_movement.mp4`
* **Reference Frame**: `animals/domestic/horse.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Horse (Equus caballus) from the reference image (animals/domestic/horse.webp) moving gently and naturally in Stables, Ranches, and Open Grassy Fields. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Donkey (`domestic_donkey`)
* **Target Path**: `videos/animals/donkey_movement.mp4`
* **Reference Frame**: `animals/domestic/donkey.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Donkey (Equus asinus) from the reference image (animals/domestic/donkey.webp) moving gently and naturally in Farms, Dry Valleys, and Village Paths. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Pig (`domestic_pig`)
* **Target Path**: `videos/animals/pig_movement.mp4`
* **Reference Frame**: `animals/domestic/pig.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Pig (Sus scrofa domesticus) from the reference image (animals/domestic/pig.webp) moving gently and naturally in Farms, Pens, and Woodland Pastures. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Rabbit (`domestic_rabbit`)
* **Target Path**: `videos/animals/rabbit_movement.mp4`
* **Reference Frame**: `animals/domestic/rabbit.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Rabbit (Oryctolagus cuniculus) from the reference image (animals/domestic/rabbit.webp) moving gently and naturally in Meadows, Gardens, and Cozy Burrows. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Camel (`domestic_camel`)
* **Target Path**: `videos/animals/camel_movement.mp4`
* **Reference Frame**: `animals/domestic/camel.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Camel (Camelus dromedarius) from the reference image (animals/domestic/camel.webp) moving gently and naturally in Warm Sandy Deserts and Arid Plains. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`
