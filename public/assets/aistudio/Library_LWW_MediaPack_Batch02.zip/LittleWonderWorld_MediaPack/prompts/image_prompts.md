# Little Wonder World 2.0 — Batch02 Image Generation Prompts

### Cow (`domestic_cow`)
* **Target Path**: `animals/domestic/cow.webp`
* **Prompt**: `A realistic, scientifically accurate adult Cow (Bos taurus) in its natural habitat (Farms, Pastures, and Rural Villages). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Buffalo (`domestic_buffalo`)
* **Target Path**: `animals/domestic/buffalo.webp`
* **Prompt**: `A realistic, scientifically accurate adult Buffalo (Bubalus bubalis) in its natural habitat (Farms, Riverbanks, and Muddy Pastures). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Goat (`domestic_goat`)
* **Target Path**: `animals/domestic/goat.webp`
* **Prompt**: `A realistic, scientifically accurate adult Goat (Capra hircus) in its natural habitat (Farms, Hillsides, and Meadows). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Sheep (`domestic_sheep`)
* **Target Path**: `animals/domestic/sheep.webp`
* **Prompt**: `A realistic, scientifically accurate adult Sheep (Ovis aries) in its natural habitat (Green Hills, Pastures, and Farm Meadows). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Horse (`domestic_horse`)
* **Target Path**: `animals/domestic/horse.webp`
* **Prompt**: `A realistic, scientifically accurate adult Horse (Equus caballus) in its natural habitat (Stables, Ranches, and Open Grassy Fields). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Donkey (`domestic_donkey`)
* **Target Path**: `animals/domestic/donkey.webp`
* **Prompt**: `A realistic, scientifically accurate adult Donkey (Equus asinus) in its natural habitat (Farms, Dry Valleys, and Village Paths). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Pig (`domestic_pig`)
* **Target Path**: `animals/domestic/pig.webp`
* **Prompt**: `A realistic, scientifically accurate adult Pig (Sus scrofa domesticus) in its natural habitat (Farms, Pens, and Woodland Pastures). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Rabbit (`domestic_rabbit`)
* **Target Path**: `animals/domestic/rabbit.webp`
* **Prompt**: `A realistic, scientifically accurate adult Rabbit (Oryctolagus cuniculus) in its natural habitat (Meadows, Gardens, and Cozy Burrows). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Camel (`domestic_camel`)
* **Target Path**: `animals/domestic/camel.webp`
* **Prompt**: `A realistic, scientifically accurate adult Camel (Camelus dromedarius) in its natural habitat (Warm Sandy Deserts and Arid Plains). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Orange (`fruit_orange`)
* **Target Path**: `objects/fruits/orange.webp`
* **Prompt**: `A single clean, accurate, child-friendly Orange (Orange), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Grapes (`fruit_grapes`)
* **Target Path**: `objects/fruits/grapes.webp`
* **Prompt**: `A single clean, accurate, child-friendly Grapes (Green / Purple), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Watermelon (`fruit_watermelon`)
* **Target Path**: `objects/fruits/watermelon.webp`
* **Prompt**: `A single clean, accurate, child-friendly Watermelon (Green outside, Red inside), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Pineapple (`fruit_pineapple`)
* **Target Path**: `objects/fruits/pineapple.webp`
* **Prompt**: `A single clean, accurate, child-friendly Pineapple (Golden Yellow), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Strawberry (`fruit_strawberry`)
* **Target Path**: `objects/fruits/strawberry.webp`
* **Prompt**: `A single clean, accurate, child-friendly Strawberry (Bright Red), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Guava (`fruit_guava`)
* **Target Path**: `objects/fruits/guava.webp`
* **Prompt**: `A single clean, accurate, child-friendly Guava (Light Green), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Papaya (`fruit_papaya`)
* **Target Path**: `objects/fruits/papaya.webp`
* **Prompt**: `A single clean, accurate, child-friendly Papaya (Orange-Yellow), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Pomegranate (`fruit_pomegranate`)
* **Target Path**: `objects/fruits/pomegranate.webp`
* **Prompt**: `A single clean, accurate, child-friendly Pomegranate (Ruby Red), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Coconut (`fruit_coconut`)
* **Target Path**: `objects/fruits/coconut.webp`
* **Prompt**: `A single clean, accurate, child-friendly Coconut (Brown / White), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`
