# Little Wonder World 2.0 — Batch03 Image Generation Prompts

### Giraffe (`wild_giraffe`)
* **Target Path**: `animals/wild/giraffe.webp`
* **Prompt**: `A realistic, scientifically accurate adult Giraffe (Giraffa camelopardalis) in its natural habitat (African Savannas and Open Woodlands). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Leopard (`wild_leopard`)
* **Target Path**: `animals/wild/leopard.webp`
* **Prompt**: `A realistic, scientifically accurate adult Leopard (Panthera pardus) in its natural habitat (Forests, Mountains, and Savanna Woodlands). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Cheetah (`wild_cheetah`)
* **Target Path**: `animals/wild/cheetah.webp`
* **Prompt**: `A realistic, scientifically accurate adult Cheetah (Acinonyx jubatus) in its natural habitat (Open Grasslands and Dry Savannas). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Bear (`wild_bear`)
* **Target Path**: `animals/wild/bear.webp`
* **Prompt**: `A realistic, scientifically accurate adult Bear (Ursus arctos) in its natural habitat (Forests, Mountains, and River Valleys). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Deer (`wild_deer`)
* **Target Path**: `animals/wild/deer.webp`
* **Prompt**: `A realistic, scientifically accurate adult Deer (Cervus elaphus) in its natural habitat (Woodlands, Meadows, and Forest Clearings). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Zebra (`wild_zebra`)
* **Target Path**: `animals/wild/zebra.webp`
* **Prompt**: `A realistic, scientifically accurate adult Zebra (Equus quagga) in its natural habitat (African Grasslands and Savannas). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Monkey (`wild_monkey`)
* **Target Path**: `animals/wild/monkey.webp`
* **Prompt**: `A realistic, scientifically accurate adult Monkey (Macaca mulatta) in its natural habitat (Tropical Forests and Woodland Canopies). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Gorilla (`wild_gorilla`)
* **Target Path**: `animals/wild/gorilla.webp`
* **Prompt**: `A realistic, scientifically accurate adult Gorilla (Gorilla beringei) in its natural habitat (Misty Mountain Forests and Tropical Jungles). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Rhinoceros (`wild_rhinoceros`)
* **Target Path**: `animals/wild/rhinoceros.webp`
* **Prompt**: `A realistic, scientifically accurate adult Rhinoceros (Ceratotherium simum) in its natural habitat (Savanna Grasslands and Floodplains). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Hippopotamus (`wild_hippopotamus`)
* **Target Path**: `animals/wild/hippopotamus.webp`
* **Prompt**: `A realistic, scientifically accurate adult Hippopotamus (Hippopotamus amphibius) in its natural habitat (Rivers, Lakes, and Swamps in Africa). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Fox (`wild_fox`)
* **Target Path**: `animals/wild/fox.webp`
* **Prompt**: `A realistic, scientifically accurate adult Fox (Vulpes vulpes) in its natural habitat (Forests, Meadows, and Hillsides). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Wolf (`wild_wolf`)
* **Target Path**: `animals/wild/wolf.webp`
* **Prompt**: `A realistic, scientifically accurate adult Wolf (Canis lupus) in its natural habitat (Northern Forests, Tundra, and Mountains). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Kangaroo (`wild_kangaroo`)
* **Target Path**: `animals/wild/kangaroo.webp`
* **Prompt**: `A realistic, scientifically accurate adult Kangaroo (Macropus rufus) in its natural habitat (Australian Bushlands and Open Plains). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Panda (`wild_panda`)
* **Target Path**: `animals/wild/panda.webp`
* **Prompt**: `A realistic, scientifically accurate adult Panda (Ailuropoda melanoleuca) in its natural habitat (Misty Bamboo Mountain Forests in China). Full body clearly visible, natural colors and realistic anatomy, gentle child-friendly posture, 1024x1024 resolution, authentic wildlife photography style, clean composition, text-free, no labels, no watermarks.`

### Carrot (`veg_carrot`)
* **Target Path**: `objects/vegetables/carrot.webp`
* **Prompt**: `A single clean, accurate, child-friendly Carrot (Orange), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Potato (`veg_potato`)
* **Target Path**: `objects/vegetables/potato.webp`
* **Prompt**: `A single clean, accurate, child-friendly Potato (Light Brown), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Tomato (`veg_tomato`)
* **Target Path**: `objects/vegetables/tomato.webp`
* **Prompt**: `A single clean, accurate, child-friendly Tomato (Bright Red), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Onion (`veg_onion`)
* **Target Path**: `objects/vegetables/onion.webp`
* **Prompt**: `A single clean, accurate, child-friendly Onion (Purple / Pink), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Brinjal (`veg_brinjal`)
* **Target Path**: `objects/vegetables/brinjal.webp`
* **Prompt**: `A single clean, accurate, child-friendly Brinjal (Glossy Purple), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Cabbage (`veg_cabbage`)
* **Target Path**: `objects/vegetables/cabbage.webp`
* **Prompt**: `A single clean, accurate, child-friendly Cabbage (Leafy Green), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Cauliflower (`veg_cauliflower`)
* **Target Path**: `objects/vegetables/cauliflower.webp`
* **Prompt**: `A single clean, accurate, child-friendly Cauliflower (Creamy White), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Pumpkin (`veg_pumpkin`)
* **Target Path**: `objects/vegetables/pumpkin.webp`
* **Prompt**: `A single clean, accurate, child-friendly Pumpkin (Orange), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Cucumber (`veg_cucumber`)
* **Target Path**: `objects/vegetables/cucumber.webp`
* **Prompt**: `A single clean, accurate, child-friendly Cucumber (Cool Green), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Peas (`veg_peas`)
* **Target Path**: `objects/vegetables/peas.webp`
* **Prompt**: `A single clean, accurate, child-friendly Peas (Bright Green), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`

### Beetroot (`veg_beetroot`)
* **Target Path**: `objects/vegetables/beetroot.webp`
* **Prompt**: `A single clean, accurate, child-friendly Beetroot (Deep Ruby Red), centered and isolated on a solid seamless white background. Consistent studio lighting, 1024x1024 resolution, no text, no clutter, no watermarks.`
