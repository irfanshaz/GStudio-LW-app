# Little Wonder World 2.0 — Batch03 Google Veo 2 Video Prompts

### Giraffe (`wild_giraffe`)
* **Target Path**: `videos/animals/giraffe_movement.mp4`
* **Reference Frame**: `animals/wild/giraffe.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Giraffe (Giraffa camelopardalis) from the reference image (animals/wild/giraffe.webp) moving gently and naturally in African Savannas and Open Woodlands. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Leopard (`wild_leopard`)
* **Target Path**: `videos/animals/leopard_movement.mp4`
* **Reference Frame**: `animals/wild/leopard.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Leopard (Panthera pardus) from the reference image (animals/wild/leopard.webp) moving gently and naturally in Forests, Mountains, and Savanna Woodlands. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Cheetah (`wild_cheetah`)
* **Target Path**: `videos/animals/cheetah_movement.mp4`
* **Reference Frame**: `animals/wild/cheetah.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Cheetah (Acinonyx jubatus) from the reference image (animals/wild/cheetah.webp) moving gently and naturally in Open Grasslands and Dry Savannas. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Bear (`wild_bear`)
* **Target Path**: `videos/animals/bear_movement.mp4`
* **Reference Frame**: `animals/wild/bear.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Bear (Ursus arctos) from the reference image (animals/wild/bear.webp) moving gently and naturally in Forests, Mountains, and River Valleys. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Deer (`wild_deer`)
* **Target Path**: `videos/animals/deer_movement.mp4`
* **Reference Frame**: `animals/wild/deer.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Deer (Cervus elaphus) from the reference image (animals/wild/deer.webp) moving gently and naturally in Woodlands, Meadows, and Forest Clearings. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Zebra (`wild_zebra`)
* **Target Path**: `videos/animals/zebra_movement.mp4`
* **Reference Frame**: `animals/wild/zebra.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Zebra (Equus quagga) from the reference image (animals/wild/zebra.webp) moving gently and naturally in African Grasslands and Savannas. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Monkey (`wild_monkey`)
* **Target Path**: `videos/animals/monkey_movement.mp4`
* **Reference Frame**: `animals/wild/monkey.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Monkey (Macaca mulatta) from the reference image (animals/wild/monkey.webp) moving gently and naturally in Tropical Forests and Woodland Canopies. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Gorilla (`wild_gorilla`)
* **Target Path**: `videos/animals/gorilla_movement.mp4`
* **Reference Frame**: `animals/wild/gorilla.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Gorilla (Gorilla beringei) from the reference image (animals/wild/gorilla.webp) moving gently and naturally in Misty Mountain Forests and Tropical Jungles. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Rhinoceros (`wild_rhinoceros`)
* **Target Path**: `videos/animals/rhinoceros_movement.mp4`
* **Reference Frame**: `animals/wild/rhinoceros.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Rhinoceros (Ceratotherium simum) from the reference image (animals/wild/rhinoceros.webp) moving gently and naturally in Savanna Grasslands and Floodplains. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Hippopotamus (`wild_hippopotamus`)
* **Target Path**: `videos/animals/hippopotamus_movement.mp4`
* **Reference Frame**: `animals/wild/hippopotamus.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Hippopotamus (Hippopotamus amphibius) from the reference image (animals/wild/hippopotamus.webp) moving gently and naturally in Rivers, Lakes, and Swamps in Africa. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Fox (`wild_fox`)
* **Target Path**: `videos/animals/fox_movement.mp4`
* **Reference Frame**: `animals/wild/fox.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Fox (Vulpes vulpes) from the reference image (animals/wild/fox.webp) moving gently and naturally in Forests, Meadows, and Hillsides. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Wolf (`wild_wolf`)
* **Target Path**: `videos/animals/wolf_movement.mp4`
* **Reference Frame**: `animals/wild/wolf.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Wolf (Canis lupus) from the reference image (animals/wild/wolf.webp) moving gently and naturally in Northern Forests, Tundra, and Mountains. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Kangaroo (`wild_kangaroo`)
* **Target Path**: `videos/animals/kangaroo_movement.mp4`
* **Reference Frame**: `animals/wild/kangaroo.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Kangaroo (Macropus rufus) from the reference image (animals/wild/kangaroo.webp) moving gently and naturally in Australian Bushlands and Open Plains. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`

### Panda (`wild_panda`)
* **Target Path**: `videos/animals/panda_movement.mp4`
* **Reference Frame**: `animals/wild/panda.webp`
* **Prompt**: `Cinematic wildlife documentary footage of the exact Panda (Ailuropoda melanoleuca) from the reference image (animals/wild/panda.webp) moving gently and naturally in Misty Bamboo Mountain Forests in China. Calm, age-appropriate behavior for children aged 3-8, stable camera, 1280x720 16:9 widescreen, 5-8 seconds, no subtitles, no logos, no watermarks.`
